package com.example.bornomala

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class consonant : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consonant)
    }
}