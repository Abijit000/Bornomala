package com.example.bornomala;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class cons extends AppCompatActivity {

    MediaPlayer mediaPlayer=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cons);
    }

    public void ক(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.k);
        mediaPlayer.start();
    }

    public void খ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.kh);
        mediaPlayer.start();
    }

    public void গ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.g);
        mediaPlayer.start();
    }

    public void ঘ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.gh);
        mediaPlayer.start();
    }

    public void ঙ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.ngf);
        mediaPlayer.start();
    }

    public void চ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.c);
        mediaPlayer.start();
    }

    public void ছ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.ch);
        mediaPlayer.start();
    }

    public void জ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.j);
        mediaPlayer.start();
    }

    public void ঝ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.jh);
        mediaPlayer.start();
    }

    public void ঞ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.ngs);
        mediaPlayer.start();
    }

    public void ট(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.t);
        mediaPlayer.start();
    }

    public void ঠ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.th);
        mediaPlayer.start();
    }

    public void ড(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.d);
        mediaPlayer.start();
    }

    public void ঢ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.dha);
        mediaPlayer.start();
    }

    public void ণ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.n);
        mediaPlayer.start();
    }

    public void ত(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.tb);
        mediaPlayer.start();
    }

    public void থ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.thb);
        mediaPlayer.start();
    }

    public void দ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.db);
        mediaPlayer.start();
    }

    public void ধ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.dhab);
        mediaPlayer.start();
    }

    public void ন(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.nb);
        mediaPlayer.start();
    }

    public void প(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.p);
        mediaPlayer.start();
    }

    public void ফ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.ph);
        mediaPlayer.start();
    }

    public void ব(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.b);
        mediaPlayer.start();
    }

    public void ভ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.v);
        mediaPlayer.start();
    }

    public void ম(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.m);
        mediaPlayer.start();
    }

    public void য(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.z);
        mediaPlayer.start();
    }

    public void র(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.r);
        mediaPlayer.start();
    }

    public void ল(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.l);
        mediaPlayer.start();
    }

    public void শ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.sh);
        mediaPlayer.start();
    }

    public void ষ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.shb);
        mediaPlayer.start();
    }

    public void স(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.s);
        mediaPlayer.start();
    }

    public void হ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.h);
        mediaPlayer.start();
    }

    public void ড়(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.rb);
        mediaPlayer.start();
    }

    public void ঢ়(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.rh);
        mediaPlayer.start();
    }

    public void য়(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.y);
        mediaPlayer.start();
    }

    public void ৎ(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.tl);
        mediaPlayer.start();
    }

    public void anusor(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.ngl);
        mediaPlayer.start();
    }

    public void visargo(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.bis);
        mediaPlayer.start();
    }

    public void chandbindu(View view) {

        mediaPlayer= MediaPlayer.create(cons.this,R.raw.chon);
        mediaPlayer.start();
    }
}